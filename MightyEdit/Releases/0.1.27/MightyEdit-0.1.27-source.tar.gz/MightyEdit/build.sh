#!/bin/zsh
set -eu
cd "${0:A:h}"
# Keep a certificate-backed identity across builds so Accessibility grants can
# track the app rather than a changing ad-hoc code hash. Do not silently fall back.
SIGNING_IDENTITY="${MIGHTYEDIT_SIGNING_IDENTITY:-301A41C0A37B6B578B7477229015992E8AA34E44}"
STAGING=$(mktemp -d "${TMPDIR:-/tmp/}textpalette.XXXXXX")
trap 'rm -rf "$STAGING"' EXIT
APP="$STAGING/MightyEdit.app"
mkdir -p "$APP/Contents/MacOS"
xcrun swiftc -O -target "$(uname -m)-apple-macos13.0" -module-cache-path "$STAGING/ModuleCache" -framework AppKit -framework ApplicationServices -framework Carbon Source/TextTransform.swift Source/TypographyOption.swift Source/TypographyPanel.swift Source/PaletteConfiguration.swift Source/AppAutoShow.swift Source/DateTransform.swift Source/LocalHelp.swift Source/PaletteButton.swift Source/ResponsiveButtonGrid.swift Source/GlobalShortcuts.swift Source/WrapPanel.swift Source/SpecialListPanel.swift Source/main.swift -o "$APP/Contents/MacOS/MightyEdit"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>MightyEdit</string>
<key>CFBundleIdentifier</key><string>jp.local.TextPalette</string>
<key>CFBundleName</key><string>MightyEdit</string>
<key>CFBundleIconFile</key><string>MightyEdit</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>0.1.27</string>
<key>CFBundleVersion</key><string>28</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>LSUIElement</key><true/>
<key>LSMultipleInstancesProhibited</key><true/>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
mkdir -p "$APP/Contents/Resources"
cp Assets/MightyEdit.icns "$APP/Contents/Resources/MightyEdit.icns"
xattr -cr "$APP"
codesign --force --sign "$SIGNING_IDENTITY" --timestamp=none "$APP"
codesign --verify --deep --strict "$APP"
if [[ -e MightyEdit.app ]]; then
    mkdir -p Backups
    mv MightyEdit.app "Backups/MightyEdit-$(date +%Y%m%d-%H%M%S).app"
fi
ditto "$APP" MightyEdit.app
printf '%s\n' "$PWD/MightyEdit.app"
