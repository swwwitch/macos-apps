import AppKit
import Carbon

// Uses the same Carbon registration approach as BrowserSwitcher/Source/main.swift.
final class GlobalShortcuts: NSObject {
    var additionalPreferenceTabs: [(String, NSView)] = []
    var actionEnabled: (Int) -> Bool = { _ in true }
    func reloadConfiguration() { register() }
    let menu = NSMenu(title: "ホットキー")
    private var preferences: NSWindow?
    private var preferenceRows: [(id: Int, popup: NSPopUpButton, error: NSTextField)] = []
    private var enabledCheckbox: NSButton?
    private var pauseCheckbox: NSButton?
    private var handlerFailure: OSStatus?
    private let actions: [(id: Int, title: String, digit: Int)]
    private let perform: (Int) -> Void
    private var handler: EventHandlerRef?
    private var references: [EventHotKeyRef] = []
    private var paused = false
    private var failures: [Int: OSStatus] = [:]
    // Keep persisted values 0...13 unchanged; append triple-modifier choices.
    private let keyCodes: [UInt32] = [29, 18, 19, 20, 21, 23, 22, 26, 28, 25, 43, 43, 18, 21,
                                      29, 18, 19, 20, 21, 23, 22, 26, 28, 25, 43]

    private func label(_ value: Int) -> String {
        switch value {
        case 0...9: return "Control＋\(value)"
        case 10: return "Control＋,"
        case 11: return "Control＋Option＋,"
        case 12: return "Control＋Option＋1"
        case 13: return "Control＋Option＋4"
        case 14...23: return "Control＋Option＋⌘＋\(value - 14)"
        case 24: return "Control＋Option＋⌘＋,"
        default: return "無効"
        }
    }

    init(actions: [(id: Int, title: String, digit: Int)], perform: @escaping (Int) -> Void) {
        self.actions = actions
        self.perform = perform
        super.init()
        var type = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyReleased))
        let status = InstallEventHandler(GetApplicationEventTarget(), { _, event, context in
            guard let event, let context else { return OSStatus(eventNotHandledErr) }
            var identifier = EventHotKeyID()
            let result = GetEventParameter(event, EventParamName(kEventParamDirectObject), EventParamType(typeEventHotKeyID),
                                           nil, MemoryLayout<EventHotKeyID>.size, nil, &identifier)
            guard result == noErr, identifier.signature == 0x4D454454 else { return OSStatus(eventNotHandledErr) }
            let owner = Unmanaged<GlobalShortcuts>.fromOpaque(context).takeUnretainedValue()
            let pid = NSWorkspace.shared.frontmostApplication?.processIdentifier
            owner.performAfterRelease(Int(identifier.id), pid: pid, remaining: 50)
            return noErr
        }, 1, &type, Unmanaged.passUnretained(self).toOpaque(), &handler)
        if status != noErr { handlerFailure = status; actions.forEach { failures[$0.id] = status }; rebuildMenu() }
        else { register() }
    }

    deinit {
        references.forEach { UnregisterEventHotKey($0) }
        if let handler { RemoveEventHandler(handler) }
    }

    private func digit(_ id: Int) -> Int {
        let key = "shortcutDigit-\(id)"
        return UserDefaults.standard.object(forKey: key) == nil
            ? actions.first(where: { $0.id == id })!.digit : UserDefaults.standard.integer(forKey: key)
    }

    private func performAfterRelease(_ id: Int, pid: pid_t?, remaining: Int) {
        guard !paused, !UserDefaults.standard.bool(forKey: "shortcutsDisabled"),
              NSWorkspace.shared.frontmostApplication?.processIdentifier == pid else { return }
        if NSEvent.modifierFlags.intersection([.control, .option, .command, .shift]).isEmpty {
            if actionEnabled(id) { perform(id) }
        } else if remaining > 0 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) { [weak self] in
                self?.performAfterRelease(id, pid: pid, remaining: remaining - 1)
            }
        }
    }

    private func register() {
        references.forEach { UnregisterEventHotKey($0) }
        references.removeAll()
        failures.removeAll()
        if let handlerFailure {
            actions.forEach { failures[$0.id] = handlerFailure }
        } else if !paused && !UserDefaults.standard.bool(forKey: "shortcutsDisabled") {
            var used = Set<Int>()
            for action in actions {
                guard actionEnabled(action.id) else { continue }
                let value = digit(action.id)
                guard keyCodes.indices.contains(value) else { continue }
                guard used.insert(value).inserted else { failures[action.id] = OSStatus(eventHotKeyExistsErr); continue }
                var ref: EventHotKeyRef?
                let modifiers = UInt32(controlKey) | (value >= 11 ? UInt32(optionKey) : 0)
                    | (value >= 14 ? UInt32(cmdKey) : 0)
                let status = RegisterEventHotKey(keyCodes[value], modifiers,
                                                EventHotKeyID(signature: 0x4D454454, id: UInt32(action.id)),
                                                GetApplicationEventTarget(), 0, &ref)
                if status == noErr, let ref { references.append(ref) } else { failures[action.id] = status }
            }
        }
        rebuildMenu()
        refreshPreferences()
    }

    private func rebuildMenu() {
        menu.removeAllItems()
        let enabled = menu.addItem(withTitle: "ホットキーを有効にする", action: #selector(toggleEnabled), keyEquivalent: "")
        enabled.target = self
        enabled.state = UserDefaults.standard.bool(forKey: "shortcutsDisabled") ? .off : .on
        let pause = menu.addItem(withTitle: "一時停止", action: #selector(togglePause), keyEquivalent: "")
        pause.target = self; pause.state = paused ? .on : .off
        menu.addItem(.separator())
        for action in actions {
            let value = digit(action.id)
            let label = label(value)
            let error = failures[action.id].map { "（登録失敗：\($0)）" } ?? ""
            let root = menu.addItem(withTitle: "\(action.title)：\(label)\(error)", action: nil, keyEquivalent: "")
            let options = NSMenu(title: action.title)
            for choice in [-1] + Array(keyCodes.indices) {
                let item = options.addItem(withTitle: self.label(choice), action: #selector(choose(_:)), keyEquivalent: "")
                item.target = self
                item.representedObject = [action.id, choice]
                item.state = value == choice ? .on : .off
                item.isEnabled = choice < 0 || !actions.contains { $0.id != action.id && digit($0.id) == choice }
            }
            options.autoenablesItems = false
            root.submenu = options
        }
        menu.addItem(.separator())
        let reset = menu.addItem(withTitle: "割り当てを初期値に戻す", action: #selector(reset), keyEquivalent: "")
        reset.target = self
        if !failures.isEmpty {
            let note = menu.addItem(withTitle: "登録失敗：ほかのキーを選んでください", action: nil, keyEquivalent: "")
            note.isEnabled = false
        }
    }

    func showPreferences() {
        if preferences == nil {
            let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 640, height: 620),
                                  styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
            window.title = "MightyEdit 環境設定"
            window.isReleasedWhenClosed = false
            window.minSize = NSSize(width: 600, height: 360)
            let scroll = NSScrollView(frame: window.contentView!.bounds)
            scroll.autoresizingMask = [.width, .height]
            scroll.hasVerticalScroller = true
            window.contentView!.addSubview(scroll)
            let document = PreferencesDocumentView()
            document.translatesAutoresizingMaskIntoConstraints = false
            scroll.documentView = document
            document.widthAnchor.constraint(equalTo: scroll.contentView.widthAnchor).isActive = true
            let column = NSStackView()
            column.orientation = .vertical
            column.alignment = .leading
            column.spacing = 12
            column.translatesAutoresizingMaskIntoConstraints = false
            document.addSubview(column)
            let heading = NSTextField(labelWithString: "ホットキー")
            heading.font = .boldSystemFont(ofSize: 18)
            column.addArrangedSubview(heading)
            let enabled = NSButton(checkboxWithTitle: "ホットキーを有効にする", target: self, action: #selector(toggleEnabled))
            column.addArrangedSubview(enabled)
            enabledCheckbox = enabled
            let pause = NSButton(checkboxWithTitle: "一時停止（再起動で解除）", target: self, action: #selector(togglePause))
            column.addArrangedSubview(pause)
            pauseCheckbox = pause
            let note = NSTextField(wrappingLabelWithString: "変更はすぐに保存・反映されます。同じキーを複数の操作には割り当てられません。登録失敗時は別のキーを選んでください。")
            column.addArrangedSubview(note)
            note.widthAnchor.constraint(equalTo: column.widthAnchor).isActive = true
            let resetButton = NSButton(title: "割り当てを初期値に戻す", target: self, action: #selector(reset))
            resetButton.bezelStyle = .rounded
            column.addArrangedSubview(resetButton)
            for action in actions {
                let row = NSStackView()
                row.orientation = .horizontal
                row.spacing = 12
                let label = NSTextField(wrappingLabelWithString: action.title)
                label.widthAnchor.constraint(equalToConstant: 220).isActive = true
                row.addArrangedSubview(label)
                let popup = NSPopUpButton()
                popup.menu?.autoenablesItems = false
                for value in [-1] + Array(keyCodes.indices) {
                    popup.addItem(withTitle: self.label(value))
                    popup.lastItem?.tag = value
                }
                popup.tag = action.id
                popup.target = self
                popup.action = #selector(choosePreference(_:))
                popup.setAccessibilityLabel(action.title + "のホットキー")
                popup.widthAnchor.constraint(equalToConstant: 220).isActive = true
                row.addArrangedSubview(popup)
                column.addArrangedSubview(row)
                let error = NSTextField(wrappingLabelWithString: "")
                error.textColor = .secondaryLabelColor
                error.font = .systemFont(ofSize: 11)
                column.addArrangedSubview(error)
                preferenceRows.append((action.id, popup, error))
            }
            NSLayoutConstraint.activate([
                column.leadingAnchor.constraint(equalTo: document.leadingAnchor, constant: 24),
                column.trailingAnchor.constraint(equalTo: document.trailingAnchor, constant: -24),
                column.topAnchor.constraint(equalTo: document.topAnchor, constant: 24),
                column.bottomAnchor.constraint(equalTo: document.bottomAnchor, constant: -24)
            ])
            let tabs = NSTabView(frame: window.contentView!.bounds.insetBy(dx: 10, dy: 10))
            tabs.autoresizingMask = [.width, .height]
            let shortcutTab = NSTabViewItem(identifier: "shortcuts")
            shortcutTab.label = "ホットキー"
            scroll.removeFromSuperview()
            shortcutTab.view = scroll
            tabs.addTabViewItem(shortcutTab)
            for (label, view) in additionalPreferenceTabs {
                let tab = NSTabViewItem(identifier: label)
                tab.label = label
                tab.view = view
                tabs.addTabViewItem(tab)
            }
            window.contentView!.addSubview(tabs)
            window.center()
            window.setFrameAutosaveName("ShortcutPreferencesPosition")
            if !NSScreen.screens.contains(where: { $0.visibleFrame.intersects(window.frame) }) { window.center() }
            preferences = window
        }
        refreshPreferences()
        NSApp.activate(ignoringOtherApps: true)
        preferences?.makeKeyAndOrderFront(nil)
    }

    private func refreshPreferences() {
        enabledCheckbox?.state = UserDefaults.standard.bool(forKey: "shortcutsDisabled") ? .off : .on
        pauseCheckbox?.state = paused ? .on : .off
        for row in preferenceRows {
            row.popup.selectItem(withTag: digit(row.id))
            for item in row.popup.itemArray {
                item.isEnabled = item.tag < 0 || !actions.contains { $0.id != row.id && digit($0.id) == item.tag }
            }
            row.error.stringValue = failures[row.id].map { "登録失敗（\($0)）：別のキーを選んでください" } ?? ""
            row.error.isHidden = failures[row.id] == nil
        }
    }

    @objc private func choosePreference(_ sender: NSPopUpButton) {
        guard let choice = sender.selectedItem?.tag,
              choice < 0 || !actions.contains(where: { $0.id != sender.tag && digit($0.id) == choice }) else { refreshPreferences(); return }
        UserDefaults.standard.set(choice, forKey: "shortcutDigit-\(sender.tag)")
        register()
    }

    @objc private func choose(_ item: NSMenuItem) {
        guard let pair = item.representedObject as? [Int], pair.count == 2 else { return }
        UserDefaults.standard.set(pair[1], forKey: "shortcutDigit-\(pair[0])")
        register()
    }
    @objc private func toggleEnabled() {
        UserDefaults.standard.set(!UserDefaults.standard.bool(forKey: "shortcutsDisabled"), forKey: "shortcutsDisabled")
        register()
    }
    @objc private func togglePause() { paused.toggle(); register() }
    @objc private func reset() {
        actions.forEach { UserDefaults.standard.removeObject(forKey: "shortcutDigit-\($0.id)") }
        register()
    }
}

private final class PreferencesDocumentView: NSView {
    override var isFlipped: Bool { true }
}
