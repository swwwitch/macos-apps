import AppKit
import ApplicationServices

final class PaletteDocumentView: NSView {
    override var isFlipped: Bool { true }
}

class Palette: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    let autoShow = AppAutoShow()
    let settingsViews = PaletteSettingsViews()
    var paletteGroups: [(name: String, box: NSBox, grid: ResponsiveButtonGrid)] = []
    var panel: Palette!
    var displayItems: [NSMenuItem] = []
    let displayPicker = NSPopUpButton()
    let profilePicker = NSPopUpButton()
    var paletteButtons: [PaletteButton] = []
    var buttonGrids: [ResponsiveButtonGrid] = []
    var typographyPanel: TypographyPanel?
    var typographyOptions = TypographyOption.allCases
    var wrapPanel: WrapPanel?
    var wrapCount = 40
    var specialPanel: SpecialListPanel?
    var statusItem: NSStatusItem!
    let message = NSTextField(wrappingLabelWithString: "文字を選択して、ボタンをクリック")
    let target = NSTextField(labelWithString: "")
    var timer: Timer?
    var busy = false
    var shortcuts: GlobalShortcuts?
    var wasTrusted: Bool?
    lazy var permissionButton = NSButton(title: "アクセシビリティ設定を開く…", target: self, action: #selector(openPermission))
    var copyOnly = UserDefaults.standard.bool(forKey: "copyOnly")

    func applicationDidFinishLaunching(_ notification: Notification) {
        DispatchQueue.main.async { LocalHelp.shared.install() }
        NSApp.setActivationPolicy(.accessory)
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.image = NSImage(systemSymbolName: "textformat", accessibilityDescription: "MightyEdit")
        let menu = NSMenu()
        menu.addItem(withTitle: "パレットを表示", action: #selector(showPalette), keyEquivalent: "")
        menu.addItem(withTitle: "パレットを隠す", action: #selector(hidePalette), keyEquivalent: "")
        menu.addItem(withTitle: "環境設定…", action: #selector(showPreferences), keyEquivalent: ",")
        menu.addItem(.separator())
        let copy = menu.addItem(withTitle: "置き換えずにコピー", action: #selector(toggleCopy(_:)), keyEquivalent: "")
        copy.state = copyOnly ? .on : .off
        menu.addItem(withTitle: "アクセシビリティ設定を開く…", action: #selector(openPermission), keyEquivalent: "")
        menu.addItem(withTitle: "許可するアプリをFinderで表示", action: #selector(revealApplication), keyEquivalent: "")
        menu.addItem(.separator())
        menu.addItem(withTitle: "MightyEditを終了", action: #selector(quit), keyEquivalent: "q")
        for item in menu.items { item.target = self }
        let help = menu.addItem(withTitle: "MightyEditヘルプ", action: #selector(LocalHelp.show), keyEquivalent: "")
        help.target = LocalHelp.shared
        let display = NSMenu(title: "ボタンの表示")
        for mode in PaletteDisplayMode.allCases {
            let item = display.addItem(withTitle: mode.title, action: #selector(changeDisplay(_:)), keyEquivalent: "")
            item.target = self
            item.tag = mode.rawValue
            item.state = mode == .saved ? .on : .off
            displayItems.append(item)
        }
        let displayRoot = NSMenuItem(title: "ボタンの表示", action: nil, keyEquivalent: "")
        displayRoot.submenu = display
        menu.insertItem(displayRoot, at: 2)
        statusItem.menu = menu

        let defaults: [TextTransform: Int] = [.number: 1, .circled: 3, .alphabet: 4, .bullet: 6, .markdown: 7,
                                             .addCommas: 10, .removeCommas: 11, .bracketNumber: 12, .bracketAlphabet: 13]
        shortcuts = GlobalShortcuts(actions: TextTransform.allCases.map { ($0.rawValue, $0.title, defaults[$0] ?? -1) }) { [weak self] id in
            guard let self else { return }
            if id == TextTransform.wrapLines.rawValue { self.showWrapPanel(); return }
            if id == TextTransform.specialTypography.rawValue { self.showTypography(); return }
            let sender = NSButton()
            sender.tag = id
            self.transform(sender)
        }
        let mainMenu = NSApp.mainMenu ?? NSMenu()
        let applicationItem = NSMenuItem()
        let applicationMenu = NSMenu(title: "MightyEdit")
        let settings = applicationMenu.addItem(withTitle: "環境設定…", action: #selector(showPreferences), keyEquivalent: ",")
        settings.target = self
        applicationMenu.addItem(.separator())
        let quitItem = applicationMenu.addItem(withTitle: "MightyEditを終了", action: #selector(quit), keyEquivalent: "q")
        quitItem.target = self
        applicationItem.submenu = applicationMenu
        mainMenu.insertItem(applicationItem, at: 0)
        NSApp.mainMenu = mainMenu
        let shortcutItem = NSMenuItem(title: "ホットキー", action: nil, keyEquivalent: "")
        shortcutItem.submenu = shortcuts?.menu
        menu.insertItem(shortcutItem, at: 3)

        panel = Palette(contentRect: NSRect(x: 0, y: 0, width: 380, height: 642),
                        styleMask: [.titled, .closable, .resizable, .nonactivatingPanel, .utilityWindow], backing: .buffered, defer: false)
        panel.title = "MightyEdit"
        panel.contentMinSize = NSSize(width: 280, height: 300)
        panel.isFloatingPanel = true
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.becomesKeyOnlyIfNeeded = true
        panel.isReleasedWhenClosed = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.setFrameAutosaveName("TextPalettePosition")
        let content = NSVisualEffectView()
        content.material = .hudWindow
        content.blendingMode = .behindWindow
        content.state = .active
        panel.contentView = content
        let toolbar = NSStackView(views: [displayPicker, profilePicker])
        toolbar.spacing = 6
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(toolbar)
        displayPicker.addItems(withTitles: PaletteDisplayMode.allCases.map(\.title))
        displayPicker.selectItem(at: PaletteDisplayMode.saved.rawValue)
        displayPicker.target = self
        displayPicker.action = #selector(pickDisplay(_:))
        displayPicker.setAccessibilityLabel("ボタンの表示")
        profilePicker.addItems(withTitles: PaletteProfile.allCases.map(\.title))
        profilePicker.selectItem(at: PaletteProfile.allCases.firstIndex(of: .saved)!)
        profilePicker.target = self
        profilePicker.action = #selector(pickProfile(_:))
        profilePicker.setAccessibilityLabel("表示モード")
        for picker in [displayPicker, profilePicker] {
            picker.refusesFirstResponder = true
            picker.font = .systemFont(ofSize: 11)
            picker.controlSize = .small
        }
        NSLayoutConstraint.activate([
            toolbar.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 12),
            toolbar.trailingAnchor.constraint(lessThanOrEqualTo: content.trailingAnchor, constant: -12),
            toolbar.topAnchor.constraint(equalTo: content.topAnchor, constant: 10)
        ])
        let scroll = NSScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        scroll.drawsBackground = false
        content.addSubview(scroll)
        NSLayoutConstraint.activate([
            scroll.leadingAnchor.constraint(equalTo: content.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: content.trailingAnchor),
            scroll.topAnchor.constraint(equalTo: toolbar.bottomAnchor, constant: 4),
            scroll.bottomAnchor.constraint(equalTo: content.bottomAnchor)
        ])
        let document = PaletteDocumentView()
        document.translatesAutoresizingMaskIntoConstraints = false
        scroll.documentView = document
        document.widthAnchor.constraint(equalTo: scroll.contentView.widthAnchor).isActive = true
        let column = NSStackView()
        column.orientation = .vertical
        column.alignment = .leading
        column.spacing = 10
        column.translatesAutoresizingMaskIntoConstraints = false
        document.addSubview(column)
        target.font = .systemFont(ofSize: 11, weight: .medium)
        target.textColor = .secondaryLabelColor
        column.addArrangedSubview(target)
        let symbols = ["arrow.turn.up.left", "list.number", "list.bullet", "text.alignleft", "text.badge.minus", "1.circle", "a.square", "plus.circle", "minus.circle", "line.3.horizontal.decrease", "arrow.up.and.down.text.horizontal", "plus.circle", "minus.circle", "number", "a.square", "arrow.down.right.and.arrow.up.left", "arrow.triangle.merge", "textformat.abc", "textformat", "arrow.left.and.right.righttriangle.left.righttriangle.right", "arrow.left.and.right", "sum", "textformat.size.larger", "textformat.size.smaller", "textformat.abc", "textformat"]
        let extraSymbols: [TextTransform: String] = [.sortLines: "arrow.up.arrow.down", .uniqueLines: "doc.on.doc", .joinWestern: "text.word.spacing", .wrapLines: "text.insert", .randomLines: "shuffle", .toggleDateFormat: "calendar", .camelCase: "textformat.abc"]
        let groups = PaletteConfiguration.groups
        for (title, operations) in groups {
            var buttons: [PaletteButton] = []
            for operation in operations {
                    let button = PaletteButton(frame: .zero)
                    button.title = operation.title
                    button.target = self
                    button.action = operation == .wrapLines ? #selector(showWrapPanel) : #selector(transform(_:))
                    button.tag = operation.rawValue
                    button.image = NSImage(systemSymbolName: extraSymbols[operation] ?? (symbols.indices.contains(operation.rawValue) ? symbols[operation.rawValue] : "calendar"), accessibilityDescription: nil)?.withSymbolConfiguration(.init(pointSize: 20, weight: .regular))
                    button.imagePosition = .imageAbove
                    configureDisplay(button)
                    switch operation {
                    case .dateToISO, .dateToJapanese, .dateToEra, .dateToGregorian, .removeDateYear, .addDateYear, .weekdayShort, .weekdayLong:
                        button.toolTip = "選択テキスト内の日付を変換（存在しない日付は保持）"
                    case .narrowAlphanumerics: button.toolTip = "全角の英字・数字だけを半角に変換（記号やカナは保持）"
                    case .widenKana: button.toolTip = "半角カナを全角に変換（濁点・半濁点を結合）"
                    case .removeJapaneseSpaces: button.toolTip = "日本語と半角英数字の間の半角・全角スペースを削除"
                    case .addJapaneseSpaces: button.toolTip = "日本語と半角英数字の間を半角スペース1つに揃える"
                    case .fullwidthWestern: button.toolTip = "半角英数字・記号・スペースを全角に（カナは保持）"
                    case .halfwidthWestern: button.toolTip = "全角英数字・記号・スペースを半角に（カナは保持）"
                    case .capitalizeWords: button.toolTip = "英語の各単語の先頭を大文字、残りを小文字に"
                    case .camelCase: button.toolTip = "hello world → helloWorld（空白・ハイフン・アンダースコア区切りに対応）"
                    case .titleCase: button.toolTip = "英語のタイトル形式（先頭・末尾と主要語を大文字に）"
                    case .sum: button.toolTip = "選択範囲の数字を合算し、元の文章の下に空行と合計を追加"
                    case .wrapLines: button.toolTip = "文字数を指定して各行を折り返す（既存の改行は保持）"
                    case .toggleDateFormat: button.toolTip = "yyyy年mm月dd日とyyyy-mm-ddを相互変換（月日を2桁に揃える）"
                    case .randomLines: button.toolTip = "行単位でランダムに並べ替え（空行・重複行も保持）"
                    case .sortLines: button.toolTip = "行単位で昇順に並べ替え。すでに昇順なら降順に（数字の大小を考慮）"
                    case .uniqueLines: button.toolTip = "完全に一致する行を削除し、最初の行と順序を保持"
                    case .joinWestern: button.toolTip = "空行を残し、本文の改行を半角スペース1つで連結"
                    case .join: button.toolTip = "空行を区切りとして残し、本文の改行を削除して連結"
                    case .joinAll: button.toolTip = "空行も含むすべての改行を削除して連結"
                    case .minify: button.toolTip = "HTMLの改行・強制改行文字・タブを削除し、連続スペースを1つにまとめる"
                    case .removeBlankLines: button.toolTip = "空白・タブだけの行を含む空行を削除"
                    case .spaceLines: button.toolTip = "既存の空行を整理し、各行の間に空行を1つ入れる"
                    case .addPeriod: button.toolTip = "各行の末尾に。を付ける（すでにある場合は重複させない）"
                    case .removePeriod: button.toolTip = "各行の末尾の。を削除（文中は保持）"
                    case .addCommas: button.toolTip = "数値の整数部分を3桁ごとにカンマで区切る"
                    case .removeCommas: button.toolTip = "数値の桁区切りカンマを削除する"
                    case .removeList: button.toolTip = "行頭の番号や箇条書き記号を削除"
                    case .number: button.toolTip = "Control＋1：1. ／ Control＋Option＋1：［1］"
                    case .alphabet: button.toolTip = "Control＋4：A. ／ Control＋Option＋4：［A］"
                    default: button.toolTip = "既存の番号・記号を除去して各行に付加（空行は保持）"
                    }
                    button.toolTip = operation.title + "：" + (button.toolTip ?? "")
                buttons.append(button)
            }
            if title == "リスト" || title == "文字の整形" {
                let button = PaletteButton(frame: .zero)
                button.title = PaletteConfiguration.specialTitle(for: title)
                button.tag = title == "リスト" ? PaletteConfiguration.listSpecialID : PaletteConfiguration.typographySpecialID
                button.target = self
                button.action = title == "リスト" ? #selector(showSpecialLists) : #selector(showTypography)
                button.image = NSImage(systemSymbolName: "list.star", accessibilityDescription: nil)
                button.imagePosition = .imageAbove
                button.toolTip = title == "リスト" ? "その他のリスト：別ウインドウでリストの種類を選んで適用" : "まとめて整形：項目を選んでまとめて適用"
                configureDisplay(button)
                buttons.append(button)
            }
            let rows = ResponsiveButtonGrid(buttons: buttons, buttonHeight: displayHeight)
            buttonGrids.append(rows)
            let group = NSBox()
            group.title = title
            group.titleFont = .systemFont(ofSize: 12, weight: .semibold)
            group.contentViewMargins = NSSize(width: 10, height: 10)
            let groupContent = NSView()
            group.contentView = groupContent
            rows.translatesAutoresizingMaskIntoConstraints = false
            groupContent.addSubview(rows)
            NSLayoutConstraint.activate([
                rows.leadingAnchor.constraint(equalTo: groupContent.leadingAnchor),
                rows.trailingAnchor.constraint(equalTo: groupContent.trailingAnchor),
                rows.topAnchor.constraint(equalTo: groupContent.topAnchor),
                rows.bottomAnchor.constraint(equalTo: groupContent.bottomAnchor)
            ])
            paletteGroups.append((title, group, rows))
            column.addArrangedSubview(group)
            group.widthAnchor.constraint(equalTo: column.widthAnchor).isActive = true
        }
        message.font = .systemFont(ofSize: 11)
        message.textColor = .secondaryLabelColor
        column.addArrangedSubview(message)
        permissionButton.bezelStyle = .rounded
        permissionButton.refusesFirstResponder = true
        column.addArrangedSubview(permissionButton)
        NSLayoutConstraint.activate([
            column.leadingAnchor.constraint(equalTo: document.leadingAnchor, constant: 16),
            column.trailingAnchor.constraint(equalTo: document.trailingAnchor, constant: -16),
            column.topAnchor.constraint(equalTo: document.topAnchor, constant: 14),
            message.widthAnchor.constraint(equalTo: column.widthAnchor),
            target.widthAnchor.constraint(equalTo: column.widthAnchor),
            column.bottomAnchor.constraint(equalTo: document.bottomAnchor, constant: -14)
        ])
        if !panel.setFrameUsingName("TextPalettePosition") { panel.center() }
        if let screen = panel.screen ?? NSScreen.main {
            var frame = panel.frame
            frame.size.width = min(max(frame.width, 280), screen.visibleFrame.width)
            frame.size.height = min(max(frame.height, 300), screen.visibleFrame.height)
            frame.origin.x = max(screen.visibleFrame.minX, min(frame.origin.x, screen.visibleFrame.maxX - frame.width))
            frame.origin.y = max(screen.visibleFrame.minY, min(frame.origin.y, screen.visibleFrame.maxY - frame.height))
            panel.setFrame(frame, display: false)
        }
        settingsViews.onChange = { [weak self] in
            self?.applyVisibility()
            self?.specialPanel?.reloadOptions()
            self?.typographyPanel?.reloadOptions()
            self?.shortcuts?.reloadConfiguration()
        }
        shortcuts?.additionalPreferenceTabs = settingsViews.tabs() + [("自動表示", autoShow.makeSettingsView())]
        autoShow.showPalette = { [weak self] in self?.showPalette() }
        autoShow.start()
        shortcuts?.actionEnabled = { id in
            guard let operation = TextTransform(rawValue: id), TextTransform.specialLists.contains(operation) else { return true }
            return PaletteConfiguration.listEnabled(id)
        }
        shortcuts?.reloadConfiguration()
        applyVisibility()
        showPalette()
        updateTarget()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.updateTarget() }
    }

    func updateTarget() {
        let name = NSWorkspace.shared.frontmostApplication?.localizedName ?? "アプリ"
        target.stringValue = "対象：\(name)  ·  \(copyOnly ? "コピー" : "選択範囲を置換")"
        let trusted = AXIsProcessTrusted()
        permissionButton.isHidden = trusted
        if !trusted {
            message.stringValue = "選択文字の操作には許可が必要です。設定でMightyEditをONにしてください。"
        } else if wasTrusted != true {
            message.stringValue = "許可を確認しました。対象アプリで文字を選択してください。"
        }
        wasTrusted = trusted
        // Dim only on a definite read-only/non-text focus; unknown custom editors stay usable.
        if panel.isVisible && trusted { panel.alphaValue = focusedTextIsEditable() == false ? 0.45 : 1 }
        else { panel.alphaValue = 1 }
    }

    private func focusedTextIsEditable() -> Bool? {
        guard let app = NSWorkspace.shared.frontmostApplication,
              app.processIdentifier != ProcessInfo.processInfo.processIdentifier else { return nil }
        let ax = AXUIElementCreateApplication(app.processIdentifier)
        AXUIElementSetMessagingTimeout(ax, 0.08)
        var focused: CFTypeRef?
        guard AXUIElementCopyAttributeValue(ax, kAXFocusedUIElementAttribute as CFString, &focused) == .success,
              let focused, CFGetTypeID(focused) == AXUIElementGetTypeID() else { return nil }
        let element = unsafeBitCast(focused, to: AXUIElement.self)
        var editable: CFTypeRef?
        if AXUIElementCopyAttributeValue(element, "AXEditable" as CFString, &editable) == .success,
           let editable = editable as? Bool { return editable }
        for attribute in [kAXSelectedTextAttribute, kAXValueAttribute] {
            var settable = DarwinBoolean(false)
            if AXUIElementIsAttributeSettable(element, attribute as CFString, &settable) == .success, settable.boolValue { return true }
        }
        var role: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, kAXRoleAttribute as CFString, &role) == .success,
              let role = role as? String else { return nil }
        if ["AXStaticText", "AXImage", "AXButton", "AXToolbar", "AXMenuBar", "AXScrollArea", "AXOutline", "AXTable"].contains(role) { return false }
        return nil
    }

    private func configureDisplay(_ button: PaletteButton) {
        button.setAccessibilityLabel(button.title)
        paletteButtons.append(button)
    }

    private var displayHeight: CGFloat {
        switch PaletteDisplayMode.saved {
        case .both: return 74
        case .iconOnly: return 44
        case .textOnly: return 48
        }
    }

    @objc func changeDisplay(_ sender: NSMenuItem) {
        guard let mode = PaletteDisplayMode(rawValue: sender.tag) else { return }
        setDisplay(mode)
    }
    @objc func pickDisplay(_ sender: NSPopUpButton) {
        guard let mode = PaletteDisplayMode(rawValue: sender.indexOfSelectedItem) else { return }
        setDisplay(mode)
    }
    @objc func pickProfile(_ sender: NSPopUpButton) {
        let profile = PaletteProfile.allCases[sender.indexOfSelectedItem]
        UserDefaults.standard.set(profile.rawValue, forKey: "paletteProfile")
        applyVisibility()
    }
    private func setDisplay(_ mode: PaletteDisplayMode) {
        displayPicker.selectItem(at: mode.rawValue)
        UserDefaults.standard.set(mode.rawValue, forKey: "paletteDisplayMode")
        for item in displayItems { item.state = item.tag == mode.rawValue ? .on : .off }
        for button in paletteButtons { button.displayMode = mode }
        for grid in buttonGrids { grid.buttonHeight = displayHeight }
    }

    private func applyVisibility() {
        for group in paletteGroups {
            for button in group.grid.buttons { button.isHidden = !PaletteConfiguration.shown("button.\(button.tag)") }
            group.grid.refreshVisibility()
            group.box.isHidden = !PaletteConfiguration.shown(PaletteConfiguration.categoryKey(for: group.name)) || group.grid.buttons.allSatisfy { $0.isHidden }
        }
    }

    @objc func showPreferences() { settingsViews.editProfile(.saved); shortcuts?.showPreferences() }

    @objc func showTypography() {
        if typographyPanel == nil {
            typographyPanel = TypographyPanel { [weak self] options in
                guard let self else { return "" }
                self.typographyOptions = options
                let button = NSButton()
                button.tag = TextTransform.specialTypography.rawValue
                self.transform(button)
                return self.message.stringValue
            }
        }
        typographyPanel?.reloadOptions()
        typographyPanel?.orderFrontRegardless()
    }

    @objc func showWrapPanel() {
        if wrapPanel == nil {
            wrapPanel = WrapPanel { [weak self] count in
                guard let self else { return "" }
                self.wrapCount = count
                let button = NSButton()
                button.tag = TextTransform.wrapLines.rawValue
                self.transform(button)
                return self.message.stringValue
            }
        }
        wrapPanel?.orderFrontRegardless()
    }

    @objc func showSpecialLists() {
        if specialPanel == nil {
            specialPanel = SpecialListPanel { [weak self] operation in
                let sender = NSButton()
                sender.tag = operation.rawValue
                self?.transform(sender)
                return self?.message.stringValue ?? ""
            }
        }
        specialPanel?.reloadOptions()
        specialPanel?.orderFrontRegardless()
    }

    @objc func showPalette() { panel.orderFrontRegardless() }
    @objc func hidePalette() { panel.orderOut(nil) }
    @objc func quit() { NSApp.terminate(nil) }
    @objc func toggleCopy(_ sender: NSMenuItem) {
        copyOnly.toggle()
        UserDefaults.standard.set(copyOnly, forKey: "copyOnly")
        sender.state = copyOnly ? .on : .off
        updateTarget()
    }
    @objc func openPermission() {
        // Open only on explicit request. Never reissue the OS permission prompt.
        NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility")!)
    }

    @objc func revealApplication() {
        NSWorkspace.shared.activateFileViewerSelecting([Bundle.main.bundleURL])
    }

    private func selectReplacement(in element: AXUIElement, application: AXUIElement,
                                   pid: pid_t, original: CFRange, replacement: String,
                                   expectedDocument: String?, attempts: Int = 8) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            guard let self, NSWorkspace.shared.frontmostApplication?.processIdentifier == pid else { return }
            var focused: CFTypeRef?
            guard AXUIElementCopyAttributeValue(application, kAXFocusedUIElementAttribute as CFString, &focused) == .success,
                  let focused, CFEqual(focused, element) else { return }
            var currentValue: CFTypeRef?
            var current = CFRange()
            guard AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, &currentValue) == .success,
                  let currentValue, CFGetTypeID(currentValue) == AXValueGetTypeID(),
                  AXValueGetValue(unsafeBitCast(currentValue, to: AXValue.self), .cfRange, &current) else { return }
            // Accessibility ranges use UTF-16 units, including for emoji.
            var inserted = CFRange(location: original.location, length: replacement.utf16.count)
            guard let insertedValue = AXValueCreate(.cfRange, &inserted) else { return }
            var actual: CFTypeRef?
            let contentMatches: Bool
            if let expectedDocument {
                contentMatches = AXUIElementCopyAttributeValue(element, kAXValueAttribute as CFString, &actual) == .success
                    && (actual as? String) == expectedDocument
            } else {
                contentMatches = AXUIElementCopyParameterizedAttributeValue(element, kAXStringForRangeParameterizedAttribute as CFString,
                                                                            insertedValue, &actual) == .success
                    && (actual as? String) == replacement
            }
            let caretAtEnd = current.length == 0 && current.location == inserted.location + inserted.length
            let alreadySelected = current.location == inserted.location && current.length == inserted.length
            if contentMatches && (caretAtEnd || alreadySelected) {
                if alreadySelected { return }
                let status = AXUIElementSetAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, insertedValue)
                var readback: CFTypeRef?
                var selectedRange = CFRange()
                if status == .success,
                   AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, &readback) == .success,
                   let readback, CFGetTypeID(readback) == AXValueGetTypeID(),
                   AXValueGetValue(unsafeBitCast(readback, to: AXValue.self), .cfRange, &selectedRange),
                   selectedRange.location == inserted.location, selectedRange.length == inserted.length {
                    self.message.stringValue = replacement.isEmpty ? "加工しました（選択する文字はありません）" : "加工した文字を選択しました"
                } else {
                    self.message.stringValue = "加工後の自動選択に対応していない入力欄です"
                }
                return
            }
            // Do not take selection back after the user moves the caret or changes selection.
            let unchanged = current.location == original.location && current.length == original.length
            if attempts > 1 && (unchanged || caretAtEnd) {
                self.selectReplacement(in: element, application: application, pid: pid, original: original,
                                       replacement: replacement, expectedDocument: expectedDocument, attempts: attempts - 1)
            }
        }
    }

    @objc func transform(_ sender: NSButton) {
        guard !busy, let operation = TextTransform(rawValue: sender.tag) else { return }
        guard AXIsProcessTrusted() else { updateTarget(); return }
        guard let app = NSWorkspace.shared.frontmostApplication, app.processIdentifier != ProcessInfo.processInfo.processIdentifier else {
            message.stringValue = "操作するアプリで文字を選択してください"; return
        }
        let application = AXUIElementCreateApplication(app.processIdentifier)
        AXUIElementSetMessagingTimeout(application, 1)
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(application, kAXFocusedUIElementAttribute as CFString, &value) == .success,
              let value, CFGetTypeID(value) == AXUIElementGetTypeID() else {
            message.stringValue = "このアプリの選択文字を取得できません"; return
        }
        let element = unsafeBitCast(value, to: AXUIElement.self)
        var selected: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, kAXSelectedTextAttribute as CFString, &selected) == .success,
              let text = selected as? String, !text.isEmpty else {
            message.stringValue = "文字を選択してください（選択取得に非対応のアプリでは使用不可）"; return
        }
        let result: String
        do {
            if operation == .specialTypography {
                result = TypographyOption.applyAll(text, options: typographyOptions)
            } else if operation == .wrapLines {
                result = TextTransform.wrappedText(text, count: wrapCount)
            } else {
                result = operation == .sum ? try TextTransform.summedText(text) : operation.apply(text)
            }
        } catch {
            message.stringValue = error.localizedDescription
            return
        }
        guard result != text else { message.stringValue = "変更する文字がありません"; return }
        let pasteboard = NSPasteboard.general
        if copyOnly {
            pasteboard.clearContents()
            pasteboard.setString(result, forType: .string)
            message.stringValue = "加工した文字をコピーしました"
            return
        }
        // Require a concrete nonempty range before sending Paste; never replace an entire field.
        var rangeValue: CFTypeRef?
        var range = CFRange()
        guard AXUIElementCopyAttributeValue(element, kAXSelectedTextRangeAttribute as CFString, &rangeValue) == .success,
              let rangeValue, CFGetTypeID(rangeValue) == AXValueGetTypeID(),
              AXValueGetValue(unsafeBitCast(rangeValue, to: AXValue.self), .cfRange, &range), range.length > 0 else {
            message.stringValue = "選択範囲を確認できません。「置き換えずにコピー」をお使いください"; return
        }
        guard NSWorkspace.shared.frontmostApplication?.processIdentifier == app.processIdentifier,
              let source = CGEventSource(stateID: .privateState),
              let down = CGEvent(keyboardEventSource: source, virtualKey: 9, keyDown: true),
              let up = CGEvent(keyboardEventSource: source, virtualKey: 9, keyDown: false) else {
            message.stringValue = "対象アプリを確認できません。もう一度選択してください"; return
        }
        // Confirm the document after Paste before changing the selection.
        var documentValue: CFTypeRef?
        var expectedDocument: String?
        if AXUIElementCopyAttributeValue(element, kAXValueAttribute as CFString, &documentValue) == .success,
           let document = documentValue as? String,
           range.location >= 0, range.length <= document.utf16.count,
           range.location <= document.utf16.count - range.length {
            expectedDocument = (document as NSString).replacingCharacters(
                in: NSRange(location: range.location, length: range.length), with: result)
        }
        // Save every available pasteboard representation; restore only if no later copy occurred.
        let previous: [[NSPasteboard.PasteboardType: Data]] = (pasteboard.pasteboardItems ?? []).map { item in
            var saved: [NSPasteboard.PasteboardType: Data] = [:]
            for type in item.types { if let data = item.data(forType: type) { saved[type] = data } }
            return saved
        }
        pasteboard.clearContents()
        guard pasteboard.setString(result, forType: .string) else { message.stringValue = "クリップボードに書き込めません"; return }
        let change = pasteboard.changeCount
        down.flags = .maskCommand
        up.flags = .maskCommand
        busy = true
        down.postToPid(app.processIdentifier)
        up.postToPid(app.processIdentifier)
        message.stringValue = "\(app.localizedName ?? "対象アプリ")へ貼り付けを送信しました"
        selectReplacement(in: element, application: application, pid: app.processIdentifier,
                          original: range, replacement: result, expectedDocument: expectedDocument)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in
            if pasteboard.changeCount == change {
                pasteboard.clearContents()
                let items = previous.map { saved -> NSPasteboardItem in
                    let item = NSPasteboardItem()
                    for (type, data) in saved { item.setData(data, forType: type) }
                    return item
                }
                if !items.isEmpty { pasteboard.writeObjects(items) }
            }
            self?.busy = false
        }
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.run()
